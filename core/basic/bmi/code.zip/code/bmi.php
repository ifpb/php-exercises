<?php

// BMI = weight/height²

$weight = 60.0;
$height = 1.65;
$result;

// TODO if

// Output:
//  BMI: 22.038567493113
//  Result: Normal weight

?>