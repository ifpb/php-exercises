<?php
// A = πr²

function areaOfCircle($radius) {
  // TODO
}

?>