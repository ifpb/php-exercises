<?php

function sum($a, $b) {
  // TODO
}

?>