<?php
require __DIR__.'/../src/sum.php';

// Number Tools

// adding 1 + 2
echo(sum(1, 2));
echo(3);

// adding 3 + 2
echo(sum(3, 2));
echo(5);

?>