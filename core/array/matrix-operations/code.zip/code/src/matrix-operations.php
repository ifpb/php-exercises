<?php

function addingMatrix($a, $b)
{
  // TODO
}

function multiplyingMatrix($a, $b)
{
  // TODO
}
