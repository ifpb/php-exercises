<?php

function toRoman($number)
{
  // TODO
}
