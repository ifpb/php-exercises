<?php

function fibonacci($number)
{
  // TODO
}
