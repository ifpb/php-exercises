<?php

function total($products)
{
  // TODO
}
