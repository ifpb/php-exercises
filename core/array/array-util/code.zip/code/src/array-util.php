<?php

function minimum($array) 
{
  // TODO
}

function maximum($array) 
{
  // TODO
}

function rangeValues($length, $last=0, $step=0)
{
  // TODO
}

function zip(...$arrays) 
{
  // TODO
}

function uniq($array) 
{
  // TODO
}

function sortNum($array) 
{
  // TODO
} 