<?php
 // require __DIR__ . '/../../../function/prime/code/prime.php';

/**
 * begin: 1..n
 * end: 1..n, end > begin
 */
function primes($begin, $end = 0)
{
  // TODO
}
