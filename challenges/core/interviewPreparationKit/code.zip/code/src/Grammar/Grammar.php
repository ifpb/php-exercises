<?php
namespace Grammar;

class Grammar
{
  public static function spelling($word)
  {
    // TODO
  }
}
