<?php
namespace SockMerchant;

class SockMerchant
{
  public static function sockMerchant($socks): int
  {
    // TODO
  }
}
